/* kcnative.c: a tiny C library for KingCobra's native import */
long square(long x) { return x * x; }
double half(double x) { return x / 2.0; }
long dot3(long a, long b, long c) { return a * b + c; }
