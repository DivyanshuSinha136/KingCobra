# KingCobra RHEX companion (Divyanshu Sinha)
Programs from "KingCobra RHEX: Raw Hex Execution and Machine Bytes".
Run from inside code/:  kingcobra run r01_hello.kc
r12/r13 import miniasm.kc. e*.kc are deliberate error/failure demos (e10_crash dies with SIGILL by design).
Examples assume x86-64 Linux (System V). MSR/port I/O need root + hardware and were not exercised.
